@extends('layout.app')
<div class="container-fluid page-body-wrapper">
</div>

<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/user-register', 'App\Http\Controllers\FrontEndController@user_register');
Route::get('/user-login', 'App\Http\Controllers\FrontEndController@user_login');

Route::post('/visa/store_applications', 'App\Http\Controllers\VisaController@store');


Route::post('/visa/store_offer', 'App\Http\Controllers\OfferController@store');

Route::get('/visa/{nationality}/{destination}', 'App\Http\Controllers\FrontEndController@getOffer_view');

Route::get('/visa/offers/rules/{id}', 'App\Http\Controllers\FrontEndController@getOffer_documentrules');

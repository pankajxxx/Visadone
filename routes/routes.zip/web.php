<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FrontEndController;
use App\Http\Controllers\UserController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::middleware('custom.auth')->group(function () {
    // Protected routes
    Route::get('/', function () {return view('index');
});
    // Add more protected routes here
});


Route::get('/login', function () {
    return view('layout.login');
});

Route::get('/users_create', function () {
    return view('users.create');
});

// Route::get('/offers_create', function () {
//     return view('offers.create');
// });


// ----------------------------------------------------------------------------------------------------------
// For Users
Route::get('/users', 'App\Http\Controllers\UserController@index');


// ---------------------------------------------------------------------------------------------------------
// For Visa
Route::get('/visa', 'App\Http\Controllers\VisaController@index');
Route::get('/visa/create', 'App\Http\Controllers\VisaController@create');
Route::post('/visa/store_applications', 'App\Http\Controllers\VisaController@cstore');

// ----------------------------------------------------------------------------------------------------------
// For User Types


// ----------------------------------------------------------------------------------------------------------


// For AJAX Routes
Route::get('/offers/get/{destination}', 'App\Http\Controllers\OfferController@getoffers');

// ----------------------------------------------------------------------------------------------------------

// For Offers
Route::get('/visa/offer_create', 'App\Http\Controllers\OfferController@create');
Route::post('/visa/store_offer', 'App\Http\Controllers\OfferController@store');
Route::get('/visa/offerget', 'App\Http\Controllers\OfferController@getOffer_view');
Route::get('/visa/offers', 'App\Http\Controllers\OfferController@index');


// ----------------------------------------------------------------------------------------------------------

// For Offers Rules
Route::get('/offer/rule/get', 'App\Http\Controllers\DocumentRuleController@index');

Route::get('/visa/offers/rules/{id}', 'App\Http\Controllers\FrontEndController@getDocuments');
Route::get('/offers_rules/create', 'App\Http\Controllers\DocumentRuleController@create');
Route::post('/offers_rule/store', 'App\Http\Controllers\DocumentRuleController@store');


// ----------------------------------------------------------------------------------------------------------





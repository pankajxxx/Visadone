<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;

class TrackController extends Controller
{
    //
    public function index()
    {
        // $user = Auth::user();
        // if ($user->group_id == null || $user->user_type == "S") {
        // $index['data'] = DB::table('applicants_data')->get();

        $originalData = DB::table('applicants_data')
            ->join('visa_data', 'applicants_data.visa_id', '=', 'visa_data.id')
            ->leftJoinSub(
                DB::table('visa_data')
                    ->select('id', DB::raw('COUNT(*) as application_count'))
                    ->groupBy('id'),
                'visa_counts', function ($join) {
                    $join->on('visa_counts.id', '=', 'visa_data.id');
                }
            )
            ->select(
                'visa_data.*',
                'visa_data.id',
                'visa_data.visa_type_selected',
                DB::raw('COUNT(IFNULL(visa_counts.application_count, 0)) as application_count'),

                'applicants_data.passport_number as app_number',
                'applicants_data.surname',
                'applicants_data.firstname',
                'applicants_data.nationality',
                'applicants_data.key_field',
                'applicants_data.value',
                // 'applicants_data.id',
                DB::raw('COUNT(*) as id_count')
            )
            ->groupBy('visa_data.id',
                'visa_data.id',
                'visa_data.user_id',
                'visa_data.branch_id',
                'visa_data.nationality',
                'visa_data.destination',
                'visa_data.travel_date_from',
                'visa_data.travel_date_to',
                'visa_data.visa_offer',
                'visa_data.offer_id',
                'visa_data.visa_fees',
                'visa_data.visa_status',
                'visa_data.passport_number',
                'visa_data.application_JSON',
                'visa_data.files_JSON',
                'visa_data.submitted_at',
                'visa_data.created_at',
                'visa_data.deleted_at',
                'visa_data.updated_at',
                'visa_data.visa_type_selected',
                'applicants_data.passport_number',
                'applicants_data.surname',
                'applicants_data.firstname',
                'applicants_data.nationality',
                'applicants_data.key_field',
                'applicants_data.value',
                // 'applicants_data.id',
                // 'applicants_data.visa_id'
            )
            ->get();

        // Restructure the data
        $restructuredData = [];
        foreach ($originalData as $item) {
            $visaId = $item->id;

            if (!isset($restructuredData[$visaId])) {
                $restructuredData[$visaId] = [
                    'visa_id' => $visaId,
                    'visa_type_selected' => $item->visa_type_selected,
                    'application_count' => $item->application_count,
                    'destination' => $item->destination,
                    'status' => $item->visa_status,
                    'From_date' => $item->travel_date_from,
                    'To_date' => $item->travel_date_to,
                    'created_at' => $item->created_at,
                    'Visa_offer' => $item->visa_offer,
                    'nationality' => $item->nationality,
                    'visa_type' => $item->visa_offer,

                    'applications' => [],
                ];
            }

            $restructuredData[$visaId]['applications'][] = [
                'surname' => $item->surname,
                'firstname' => $item->firstname,
                'nationality' => $item->nationality,
                'passport' => $item->app_number,
                // ... Add other application details as needed
            ];
            $restructuredData[$visaId]['application_count'] = count($restructuredData[$visaId]['applications']);
        }

        // Convert the restructured data to JSON
        $restructuredJson = json_encode(array_values($restructuredData));

        // dd($restructuredJson);
        return view("Track_Application.index", ['restructuredJson' => $restructuredJson]);

    }

    public function search_name(Request $request)
    {
        // $user = Auth::user();
        // if ($user->group_id == null || $user->user_type == "S") {
        // $index['data'] = DB::table('applicants_data')->get();
        $name = $request->search_name;

        $originalData = DB::table('applicants_data')
            ->join('visa_data', 'applicants_data.visa_id', '=', 'visa_data.id')
            ->leftJoinSub(
                DB::table('visa_data')
                    ->select('id', DB::raw('COUNT(*) as application_count'))
                    ->groupBy('id'),
                'visa_counts', function ($join) {
                    $join->on('visa_counts.id', '=', 'visa_data.id');
                }
            )
            ->select(
                'visa_data.*',
                'visa_data.id',
                'visa_data.visa_type_selected',
                DB::raw('COUNT(IFNULL(visa_counts.application_count, 0)) as application_count'),

                'applicants_data.passport_number as app_number',
                'applicants_data.surname',
                'applicants_data.firstname',
                'applicants_data.nationality',
                'applicants_data.key_field',
                'applicants_data.value',
                // 'applicants_data.id',
                DB::raw('COUNT(*) as id_count')
            )
            ->where(function ($query) use ($name) {
                $query->where('applicants_data.surname', 'LIKE', '%' . $name . '%')
                    ->orWhere('applicants_data.firstname', 'LIKE', '%' . $name . '%')
                    ->orWhere('applicants_data.passport_number', 'LIKE', '%' . $name . '%')
                    ->orWhere('visa_data.destination', 'LIKE', '%' . $name . '%')
                    ->orWhere('visa_data.nationality', 'LIKE', '%' . $name . '%');

            })
            ->groupBy('visa_data.id',
                'visa_data.id',
                'visa_data.user_id',
                'visa_data.branch_id',
                'visa_data.nationality',
                'visa_data.destination',
                'visa_data.travel_date_from',
                'visa_data.travel_date_to',
                'visa_data.visa_offer',
                'visa_data.offer_id',
                'visa_data.visa_fees',
                'visa_data.visa_status',
                'visa_data.passport_number',
                'visa_data.application_JSON',
                'visa_data.files_JSON',
                'visa_data.submitted_at',
                'visa_data.created_at',
                'visa_data.deleted_at',
                'visa_data.updated_at',
                'visa_data.visa_type_selected',
                'applicants_data.passport_number',
                'applicants_data.surname',
                'applicants_data.firstname',
                'applicants_data.nationality',
                'applicants_data.key_field',
                'applicants_data.value',
                // 'applicants_data.id',
                // 'applicants_data.visa_id'
            )
            ->get();

        // Restructure the data
        $restructuredData = [];
        foreach ($originalData as $item) {
            $visaId = $item->id;

            if (!isset($restructuredData[$visaId])) {
                $restructuredData[$visaId] = [
                    'visa_id' => $visaId,
                    'visa_type_selected' => $item->visa_type_selected,
                    'application_count' => $item->application_count,
                    'destination' => $item->destination,
                    'status' => $item->visa_status,
                    'From_date' => $item->travel_date_from,
                    'To_date' => $item->travel_date_to,
                    'created_at' => $item->created_at,
                    'Visa_offer' => $item->visa_offer,
                    'nationality' => $item->nationality,
                    'visa_type' => $item->visa_offer,

                    'applications' => [],
                ];
            }

            $restructuredData[$visaId]['applications'][] = [
                'surname' => $item->surname,
                'firstname' => $item->firstname,
                'nationality' => $item->nationality,
                'passport' => $item->app_number,
                // ... Add other application details as needed
            ];
            $restructuredData[$visaId]['application_count'] = count($restructuredData[$visaId]['applications']);
        }

        // Convert the restructured data to JSON
        $restructuredJson = json_encode(array_values($restructuredData));

        // dd($restructuredJson);
        return view("Track_Application.index", ['restructuredJson' => $restructuredJson]);

    }

    public function date_range(Request $request)
    {
        // $user = Auth::user();
        // if ($user->group_id == null || $user->user_type == "S") {
        // $index['data'] = DB::table('applicants_data')->get();

        $dateFrom = $request->from;
        $dateTo = $request->to;

        $originalData = DB::table('applicants_data')
            ->join('visa_data', 'applicants_data.visa_id', '=', 'visa_data.id')
            ->leftJoinSub(
                DB::table('visa_data')
                    ->select('id', DB::raw('COUNT(*) as application_count'))
                    ->groupBy('id'),
                'visa_counts', function ($join) {
                    $join->on('visa_counts.id', '=', 'visa_data.id');
                }
            )
            ->select(
                'visa_data.*',
                'visa_data.id',
                'visa_data.visa_type_selected',
                DB::raw('COUNT(IFNULL(visa_counts.application_count, 0)) as application_count'),

                'applicants_data.passport_number as app_number',
                'applicants_data.surname',
                'applicants_data.firstname',
                'applicants_data.nationality',
                'applicants_data.key_field',
                'applicants_data.value',
                // 'applicants_data.id',
                DB::raw('COUNT(*) as id_count')
            )
            ->where(function ($query) use ($dateFrom, $dateTo) {
                $query
                    ->whereBetween('visa_data.created_at', [$dateFrom, $dateTo]);

            })
            ->groupBy('visa_data.id',
                'visa_data.id',
                'visa_data.user_id',
                'visa_data.branch_id',
                'visa_data.nationality',
                'visa_data.destination',
                'visa_data.travel_date_from',
                'visa_data.travel_date_to',
                'visa_data.visa_offer',
                'visa_data.offer_id',
                'visa_data.visa_fees',
                'visa_data.visa_status',
                'visa_data.passport_number',
                'visa_data.application_JSON',
                'visa_data.files_JSON',
                'visa_data.submitted_at',
                'visa_data.created_at',
                'visa_data.deleted_at',
                'visa_data.updated_at',
                'visa_data.visa_type_selected',
                'applicants_data.passport_number',
                'applicants_data.surname',
                'applicants_data.firstname',
                'applicants_data.nationality',
                'applicants_data.key_field',
                'applicants_data.value',
                // 'applicants_data.id',
                // 'applicants_data.visa_id'
            )
            ->get();

        // Restructure the data
        $restructuredData = [];
        foreach ($originalData as $item) {
            $visaId = $item->id;

            if (!isset($restructuredData[$visaId])) {
                $restructuredData[$visaId] = [
                    'visa_id' => $visaId,
                    'visa_type_selected' => $item->visa_type_selected,
                    'application_count' => $item->application_count,
                    'destination' => $item->destination,
                    'status' => $item->visa_status,
                    'From_date' => $item->travel_date_from,
                    'To_date' => $item->travel_date_to,
                    'created_at' => $item->created_at,
                    'Visa_offer' => $item->visa_offer,
                    'nationality' => $item->nationality,
                    'visa_type' => $item->visa_offer,

                    'applications' => [],
                ];
            }

            $restructuredData[$visaId]['applications'][] = [
                'surname' => $item->surname,
                'firstname' => $item->firstname,
                'nationality' => $item->nationality,
                'passport' => $item->app_number,
                // ... Add other application details as needed
            ];
            $restructuredData[$visaId]['application_count'] = count($restructuredData[$visaId]['applications']);
        }

        // Convert the restructured data to JSON
        $restructuredJson = json_encode(array_values($restructuredData));

        // dd($restructuredJson);
        return view("Track_Application.index", ['restructuredJson' => $restructuredJson]);

    }

    public function status_applications(Request $request)
    {

        DB::connection()->enableQueryLog();

        $originalData = DB::table('applicants_data')
            ->join('visa_data', 'applicants_data.visa_id', '=', 'visa_data.id')
            ->leftJoinSub(
                DB::table('visa_data')
                    ->select('id', DB::raw('COUNT(*) as application_count'))
                    ->groupBy('id'),
                'visa_counts', function ($join) {
                    $join->on('visa_counts.id', '=', 'visa_data.id');
                }
            )

            ->select(
                'visa_data.*',
                'visa_data.id',
                'visa_data.visa_type_selected',
                DB::raw('COUNT(IFNULL(visa_counts.application_count, 0)) as application_count'),

                'applicants_data.passport_number as app_number',
                'applicants_data.surname',
                'applicants_data.firstname',
                'applicants_data.nationality',
                'applicants_data.key_field',
                'applicants_data.value',
                // 'applicants_data.id',
                DB::raw('COUNT(*) as id_count')
            )
            ->where('visa_data.visa_status', '!=', 'active')
            ->groupBy('visa_data.id',
                'visa_data.id',
                'visa_data.user_id',
                'visa_data.branch_id',
                'visa_data.nationality',
                'visa_data.destination',
                'visa_data.travel_date_from',
                'visa_data.travel_date_to',
                'visa_data.visa_offer',
                'visa_data.offer_id',
                'visa_data.visa_fees',
                'visa_data.visa_status',
                'visa_data.passport_number',
                'visa_data.application_JSON',
                'visa_data.files_JSON',
                'visa_data.submitted_at',
                'visa_data.created_at',
                'visa_data.deleted_at',
                'visa_data.updated_at',
                'visa_data.visa_type_selected',
                'applicants_data.passport_number',
                'applicants_data.surname',
                'applicants_data.firstname',
                'applicants_data.nationality',
                'applicants_data.key_field',
                'applicants_data.value',
                // 'applicants_data.id',
                // 'applicants_data.visa_id'
            )
            ->get();
            // dd(DB::getQueryLog());

        // Restructure the data
        $restructuredData = [];
        foreach ($originalData as $item) {
            $visaId = $item->id;

            if (!isset($restructuredData[$visaId])) {
                $restructuredData[$visaId] = [
                    'visa_id' => $visaId,
                    'visa_type_selected' => $item->visa_type_selected,
                    'application_count' => $item->application_count,
                    'destination' => $item->destination,
                    'status' => $item->visa_status,
                    'From_date' => $item->travel_date_from,
                    'To_date' => $item->travel_date_to,
                    'created_at' => $item->created_at,
                    'Visa_offer' => $item->visa_offer,
                    'nationality' => $item->nationality,
                    'visa_type' => $item->visa_offer,

                    'applications' => [],
                ];
            }

            $restructuredData[$visaId]['applications'][] = [
                'surname' => $item->surname,
                'firstname' => $item->firstname,
                'nationality' => $item->nationality,
                'passport' => $item->app_number,
                // ... Add other application details as needed
            ];
            $restructuredData[$visaId]['application_count'] = count($restructuredData[$visaId]['applications']);
        }

        // Convert the restructured data to JSON
        $restructuredJson = json_encode(array_values($restructuredData));

        dd($restructuredJson);
        return view("Track_Application.index", ['restructuredJson' => $restructuredJson]);

    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Agent;
use DB;
use Illuminate\Http\Request;

class AgentController extends Controller
{
    //
    public function index()
    {
        // $user = Auth::user();
        // if ($user->group_id == null || $user->user_type == "S") {
        $index['data'] = Agent::get();

        // }else{
        //     $index['data'] = User::where('group_id',$user->group_id)->whereUser_type("O")->get();
        //
        // }

        // dd($index);
        return view("agent.index", $index);
    }

    public function create()
    {
        $data['country'] = DB::table('country_info')->get();
        $data['agency'] = DB::table('agency_data')->get();
        $data['branch'] = DB::table('branches')->get();
        $data['agency'] = DB::table('agency_data')->get();
        //  $data['agent'] = DB::table('agency_data')->where('id', $id)->get();
        // dd($data);
        return view("agent.create", $data);
    }

    public function store(Request $request)
    {
        // dd($request);
        try {
            $id = Agent::create(['country' => $request->country,
                'branch_id' => $request->branch,
                'agency_id' => $request->agency,
                'agent_firstname' => $request->firstname,
                'agent_lastname' => $request->firstname,
                'Email' => $request->email,
                'contact_number' => $request->contact_number,
                'role' => $request->role,
                'status' => $request->status,
            ])->id;
            return redirect('/agents');
        } catch (\Exception $e) {
            // dd($e);
            return view("layout.500");
        }

    }

    public function edit($id)
    {
        try {
            $data['country'] = DB::table('country_info')->get();
            $data['currency'] = DB::table('currency_configuration_data')->get();
            $data['branch'] = DB::table('branches')->get();
            $data['agency'] = DB::table('agency_data')->get();
            $data['agent'] = DB::table('agent_data')->where('id', $id)->get();
            // dd($data);
            return view("agent.view", $data);
        } catch (\Exception $e) {
            // dd($e);
            return view("layout.500");
        }
    }

    public function update(Request $request)
    {
        // dd($request);
        try {
            DB::table('agent_data')
                ->where('id', $request->id) // Specify the condition to select the record(s) to update
                ->update(['country' => $request->country,
                    'branch_id' => $request->branch,
                    'agency_id' => $request->agency,
                    'agent_firstname' => $request->firstname,
                    'agent_lastname' => $request->firstname,
                    'Email' => $request->email,
                    'contact_number' => $request->contact_number,
                    'role' => $request->role,
                    'status' => $request->status,

                ]); // Set the new values for the columns

            return redirect('/agents');
        } catch (\Exception $e) {
            // dd($e);
            return view("layout.500");
        }
    }
}

<?php

namespace App\Http\Controllers;

use App\Http\Controllers\OCRController;
use App\Models\Visa;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class VisaController extends Controller
{
    //
    public function __construct()
    {

        // $this->middleware(['role:Admin']);
        // $this->middleware('permission:Users add',['only' => ['create']]);
        // $this->middleware('permission:Users edit',['only' => ['edit']]);
        // $this->middleware('permission:Users delete',['only' => ['bulk_delete', 'destroy']]);
        // $this->middleware('permission:Users list');
    }

    public function index()
    {
        // $user = Auth::user();
        // if ($user->group_id == null || $user->user_type == "S") {

        $index['data'] = DB::table('visa_data')
            ->join('users', 'visa_data.user_id', '=', 'users.id')
            ->select('users.*', 'visa_data.*')
            ->where('visa_data.visa_status', '=', 'active')
            ->orderby('visa_data.id', 'desc')
            ->get();
        $index['country'] = DB::table('country_info')->get();

        // }else{
        //     $index['data'] = User::where('group_id',$user->group_id)->whereUser_type("O")->get();
        //
        // }

        // dd($index);
        return view("visa.index", $index);
    }

    public function create()
    {
        $index['country'] = DB::table('country_info')->get();
        $userType = session('user_type');

        switch ($userType) {
            case 'S':$index['currency'] = DB::table('currency_converter')
                    ->get();
                break;

            case 'BB':$index['currency'] = DB::table('currency_converter')
                    ->where('country_name', session('country_origin'))
                    ->orWhere('country_name', 'United States')
                    ->get();
                break;

            case 'CC':$index['currency'] = DB::table('currency_converter')
                    ->where('country_name', session('country_origin'))
                    ->orWhere('country_name', 'United States')
                    ->get();
                break;

            case 'C':$index['currency'] = DB::table('currency_converter')
                    ->where('country_name', 'United States')
                    ->get();
                break;

            default:$index['currency'] = DB::table('currency_converter')
                    ->get();
                break;
        }

        // dd($index['currency']);
        return view("visa.create", $index);
    }

    public function edit($id)
    {
        $index['country'] = DB::table('country_info')->get();
        $userType = session('user_type');

        switch ($userType) {
            case 'S':$index['currency'] = DB::table('currency_converter')
                    ->get();
                break;

            case 'BB':$index['currency'] = DB::table('currency_converter')
                    ->where('country_name', session('country_origin'))
                    ->orWhere('country_name', 'United States')
                    ->get();
                break;

            case 'CC':$index['currency'] = DB::table('currency_converter')
                    ->where('country_name', session('country_origin'))
                    ->orWhere('country_name', 'United States')
                    ->get();
                break;

            case 'C':$index['currency'] = DB::table('currency_converter')
                    ->where('country_name', 'United States')
                    ->get();
                break;

            default:$index['currency'] = DB::table('currency_converter')
                    ->get();
                break;
        }

        // dd($index['currency']);
        return view("visa.edit", $index);
    }

    public function store(Request $request)
    {

        try {

            $id = Visa::create(['user_id' => session('id'), 'nationality' => $request->nationality, 'destination' => $request->destination, 'offer_id' => $request->offer_secrate_field, 'visa_status' => 'active'])->id;
            $user = Visa::find($id);
            $data = DB::table('visa_offer_data')->where('id', $request->offer_secrate_field)->get();
            $visa_type = $data[0]->visa_category;
            // $user->branch_id = $request->branch_id;
            $user->travel_date_from = $request->from_date ?? date('Y-m-d');
            $user->travel_date_to = $request->to_date ?? date('Y-m-d');
            $user->visa_type_selected = $request->{'switch-one-1'};
            $user->visa_fees = $request->visa_fees;
            $user->visa_offer = $data[0]->visa_validity;
            $user->visa_fees = $data[0]->base_rate_adult;

            $user->save(); // Save Data in Visa_data table  Files are remaining.

            // Storing File in Folder


            $files_name = $request->documents_name;
            $filesSaved = [];

            foreach ($files_name as $data) {
                // dd($data);

                if ($request->hasFile($data)) {
                    foreach ($request->$data as $file) {
                        // echo $file->getClientOriginalName();
                        $originalName = $file->getClientOriginalName();
                        $mimeType = $file->getClientMimeType();
                        $error = $file->getError();
                        $randomString = Str::random(6);
                        $newFileName = 'VISA_' . $id . '_' . $randomString . '.' . $file->getClientOriginalExtension();

                        // Store the file in the storage/app/public directory with the new filename
                        // The 'public' disk is configured to point to storage/app/public
                        $path = $file->storeAs('public/documents/' . $id . '/', $newFileName);
                        $filesSaved[] = [
                            'originalName' => $originalName,
                            'mimeType' => $mimeType,
                            'newFileName' => $newFileName,
                            'path' => $path,
                            'visa_id' => $id,
                        ];

                        $object1 = new OCRController();
                        $imgurl = "https://www.marineinsight.com/wp-content/uploads/2014/05/USA_visa_issued_by_Shenyang_2012-768x532.jpg";
                        $data_response = $object1->yourControllerFunction($imgurl);
                        // $data_response = str_replace('\\', '', $data_response);
                        // dd($data_response);
                        // Using OCR response Store the Values
                        $responses = $object1->OCR_data_response($id, $data_response);
                    }
                }

            }
            // dd($filesSaved);
            DB::table('visa_data')->where('id', $id)->update([
                'files_JSON' => $filesSaved,
            ]);
            // End

            // OCR Calling


            // END

            // OCR END
            $data_response_array = (array) $responses;
            $destination = $request->destination;

            // Merge the array with the 'destination' parameter
            $parameters = array_merge(['destination' => $destination, 'type' => $visa_type], $data_response_array);

            // Redirect with the merged parameters
            return redirect()->route('getfields_visa', $parameters);

        } catch (\Expection $e) {
            return view("layout.500");
        }

    }

    public function get_required_documents()
    {

    }

}

<?php

namespace App\Http\Controllers;

use App\Models\FormData;
use DB;
use Illuminate\Http\Request;

class FormsController extends Controller
{
    //
    public function getFields($country)
    {
        $data = DB::table('forms_data')->where('country', $country)->where('is_active',0)->get();

        return response()->json($data);
    }

    public function getFields_view($country)
    {
        $data['data'] = DB::table('forms_data')->where('country', $country)->get();
        $data['country'] = DB::table('country_info')->get();
        $data['country_name'] = $country;

        return view("Dynamic_form.forms_country", $data);
    }


    // public function getFields_visa($country,$responses)
    // {
    //     $data['data'] = DB::table('forms_data')->where('country', $country)->get();
    //     $data['country'] = DB::table('country_info')->get();
    //     $data['country_name'] = $country;
    //     $data['responses'] = $responses;

    //     return view("Dynamic_form.forms_country", $data);
    // }

    public function getFields_visa($type,$country,Request $request)
    {
        // Get the JSON string from the request query parameters
        $responses = $request->query('responses');
        $jsonString = $request->original;
        $arrayData = json_decode($jsonString, true);
        // dd($arrayData);

        // Decode the JSON string back into an object or array
        $data_response = json_decode($responses);

        // Assuming the required parameters are part of the $data_response object,
        // extract them from the object
        $Code = $arrayData[0]['Code'];
        $Passport_Number = $arrayData[1]['Passport_Number'];
        $Surname = $arrayData[2]['Surname'];
        $First_Name = $arrayData[3]['First_Name'];
        $Nationality = $arrayData[4]['Nationality'];
        $Sex = $arrayData[5]['Sex'];
        $Date_of_Birth = $arrayData[6]['Date_of_Birth'];
        $Place_of_birth = $arrayData[7]['Place_of_birth'];
        $Authority = $arrayData[8]['Authority'];
        $Date_of_Issue = $arrayData[9]['Date_of_Issue'];
        $Date_of_expiry = $arrayData[10]['Date_of_expiry'];
        $MRZ = $arrayData[11]['MRZ'];
        $table = $arrayData[12]['table'];

        // Fetch data from the database based on the country
        $data['data'] = DB::table('forms_data')->where('country', $country)->where('visa_type',$type)->get();
        $data['country'] = DB::table('country_info')->get();
        $data['country_name'] = $country;

        if ($data['data']->isEmpty()) {
            $message = "This country does not provide ".$type;
            $data['message'] = $message;
            return view("Dynamic_form.forms_country", $data);
        }



        // Pass the extracted parameters to the view
        $data['Code'] = $Code;
        $data['Passport_Number'] = $Passport_Number;
        $data['Surname'] = $Surname;
        $data['First_Name'] = $First_Name;
        $data['Nationality'] = $Nationality;
        $data['Sex'] = $Sex;
        $data['Date_of_Birth'] = $Date_of_Birth;
        $data['Place_of_birth'] = $Place_of_birth;
        $data['Authority'] = $Authority;
        $data['Date_of_Issue'] = $Date_of_Issue;
        $data['Date_of_expiry'] = $Date_of_expiry;
        $data['MRZ'] = $MRZ;
        $data['table'] = $table;


        // dd($data);

        return view("Dynamic_form.forms_country", $data);
    }


    public function index()
    {
        $data['country'] = DB::table('country_info')->get();

        return view("Dynamic_form.index", $data);
    }

    public function store(Request $request)
    {
        // dd($request);
        try {
            $id = FormData::create(['country' => $request->country,
                'field_name' => $request->field_name,
                'is_dropdown' => $request->is_dropdown,
                'is_required' => $request->is_required,
                'default_values' => $request->default_values])->id;
            $user = FormData::find($id);
            $data['country'] = DB::table('country_info')->get();

            return redirect('/form_fields');
        } catch (\Expection $e) {
            // dd($e);
            return view("layout.500");
        }
    }

    public function getStatus(Request $request)
    {
        // dd($ids);
        FormData::whereIn('id', $request->input('selectedIds'))->update(['is_active' => 1]);
        $message = 'Fields status retrieved successfully';
        return response()->json(['message' => $message]);
    }

    public function getStatus_enable(Request $request)
    {
        // dd($ids);
        FormData::whereIn('id', $request->input('selectedIds'))->update(['is_active' => 0]);
        $message = 'Fields status retrieved successfully';
        return response()->json(['message' => $message]);
    }

}

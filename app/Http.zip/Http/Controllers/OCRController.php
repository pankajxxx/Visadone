<?php

namespace App\Http\Controllers;

use App\Models\Applications;
use GuzzleHttp\Client;

class OCRController extends Controller
{
    // public function yourControllerFunction($img_url)
    // {

    //     $image_url = $img_url;
    //     // $ocr_model_id = "37cd19a1-7a2a-4406-ac18-39703aec03dc";

    //     // $new_url = 'https://app.nanonets.com/api/v2/OCR/Model/' . $ocr_model_id;
    //     $url = 'https://carsinafrica.in/backend_2_0/api/yourControllerFunction';

    //     // $api_key = 'b84bc39c-2232-11ee-a9e9-d2d8ad94c5df'; // Replace with your API key
    //     // $base_url = 'https://app.nanonets.com/api/v2/OCR/Model/';
    //     // $url = $base_url . $ocr_model_id . '/LabelUrls/';

    //     // $username = $api_key; // Replace with your API username
    //     // $password = $api_key; // Replace with your API password

    //     $postData = [
    //         'urls' => $image_url, // Replace with your POST data
    //         // Add any additional POST data as needed
    //     ];

    //     // $client = new Client();

    //     $client = new Client([
    //         'verify' => 'C:/wamp64/www/visaDone/cacert.pem', // Update the path to the cacert.pem file
    //     ]);

    //     try {
    //         $response = $client->request('POST', $url, [
    //             // 'auth' => [$username, $password],
    //             // 'headers' => [
    //                 'Content-Type' => 'application/json',
    //             //     // Add any additional headers you need
    //             // ],
    //             'form_params' => $postData,
    //         ]);

    //         echo "<pre>"; print_r($response); exit;
    //         return response()->json($response);
    //         // Handle the response data as needed
    //     } catch (\Exception $e) {
    //         // Handle the error if the request fails
    //         return response()->json(['error' => $e->getMessage()], 500);
    //     }
    // }use GuzzleHttp\Client;

    public function yourControllerFunction($img_url)
    {
        $image_url = $img_url;
        $url = 'https://carsinafrica.in/backend_2_0/api/yourControllerFunction';

        $postData = [
            'urls' => $image_url, // Replace with your POST data
            // Add any additional POST data as needed
        ];

        $client = new Client([
            'verify' => 'C:/wamp64/www/visaDone/cacert.pem', // Update the path to the cacert.pem file
        ]);

        try {
            $response = $client->request('POST', $url, [
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
                'json' => $postData,
            ]);

            // $responseData = json_decode($response->getBody(), true);
            $responseData = json_decode($response, true);
            // dd($responseData);
            // Create a response with the encoded data and set the appropriate encoding
            $encodedResponse = response()->json($responseData, 200, ['Content-Type' => 'application/json; charset=utf-8']);

            // Set any additional headers if needed
            $encodedResponse->header('Content-Encoding', 'utf-8');

            return $encodedResponse;
            // return response()->json($responseData);
            // Handle the response data as needed
        } catch (\Exception $e) {
            // Handle the error if the request fails
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function OCR_data_response($id, $response)
    {

        $response = '{
            "message": "Success",
            "result": [
                {
                    "message": "Success",
                    "input": "https://carsinafrica.in/assets/visa_img/visa_1.jpg",
                    "prediction": [
                        {
                            "id": "c12405e9-32fa-4c74-8cc3-ddb4eb6c3c58",
                            "label": "Code",
                            "xmin": 577,
                            "ymin": 95,
                            "xmax": 625,
                            "ymax": 118,
                            "score": 0.99983834999999998682795876447926275432109832763671875,
                            "ocr_text": "IND",
                            "type": "field",
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": "85260547-4cd1-42c8-8888-4e2c7ee83d27"
                        },
                        {
                            "id": "d6bee74c-c71e-4336-bbc6-e8cba5f0451b",
                            "label": "Passport_Number",
                            "xmin": 761,
                            "ymin": 94,
                            "xmax": 958,
                            "ymax": 122,
                            "score": 0.9858441399999999799064198668929748237133026123046875,
                            "ocr_text": "24813398",
                            "type": "field",
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": "e888677a-4598-4d76-b4e3-19cfbd3657c5"
                        },
                        {
                            "id": "adb2ca65-615e-477c-93a3-be1eefaf60d6",
                            "label": "Surname",
                            "xmin": 353,
                            "ymin": 138,
                            "xmax": 430,
                            "ymax": 158,
                            "score": 0.69544934999999996616537600857554934918880462646484375,
                            "ocr_text": "JOSHI",
                            "type": "field",
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": "60b9e330-0d62-49f1-9e1e-14adfc034fff"
                        },
                        {
                            "id": "1c173403-65ce-42c3-96e6-94bbafec84c3",
                            "label": "First_Name",
                            "xmin": 350,
                            "ymin": 193,
                            "xmax": 474,
                            "ymax": 213,
                            "score": 0.99653362999999994809030567921581678092479705810546875,
                            "ocr_text": "ASHUTOSH",
                            "type": "field",
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": "23dcb809-8bdc-4cd2-8d3c-6a442b48374a"
                        },
                        {
                            "id": "a311191b-8128-4ea1-ab75-eea43203074b",
                            "label": "Nationality",
                            "xmin": 438,
                            "ymin": 262,
                            "xmax": 534,
                            "ymax": 282,
                            "score": 0.997989299999999968093788993428461253643035888671875,
                            "ocr_text": "INDIAN",
                            "type": "field",
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": "23eced36-95c1-4761-bde5-58e1f05ac122"
                        },
                        {
                            "id": "424f8349-45fc-4f21-99e3-305ea99342ee",
                            "label": "Sex",
                            "xmin": 641,
                            "ymin": 260,
                            "xmax": 658,
                            "ymax": 274,
                            "score": 0.9997255000000000446647163698798976838588714599609375,
                            "ocr_text": "M",
                            "type": "field",
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": "9078a54f-9d0f-49c4-9a31-9eaecc037f65"
                        },
                        {
                            "id": "a31df627-7e3e-4bf9-8619-9de946f951ae",
                            "label": "Date_of_Birth",
                            "xmin": 745,
                            "ymin": 249,
                            "xmax": 901,
                            "ymax": 274,
                            "score": 0.99953700000000000880362449606764130294322967529296875,
                            "ocr_text": "29/07/1989",
                            "type": "field",
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": "9a8cf13a-dcaf-4d1f-bcdf-a89962492dc5"
                        },
                        {
                            "id": "4531d00b-c7f8-4d31-a1d2-ced22f0749f7",
                            "label": "Place_of_birth",
                            "xmin": 341,
                            "ymin": 317,
                            "xmax": 585,
                            "ymax": 345,
                            "score": 0.96106480000000005237126288193394429981708526611328125,
                            "ocr_text": "AJMER , RAJASTHAN",
                            "type": "field",
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": "3416d9f5-b0cf-4bdf-9fc9-e5a7f03deb30"
                        },
                        {
                            "id": "539c84f8-88b7-4a94-a6be-89e54dd8adf2",
                            "label": "Authority",
                            "xmin": 429,
                            "ymin": 384,
                            "xmax": 510,
                            "ymax": 403,
                            "score": 0.95230789999999998496349462584475986659526824951171875,
                            "ocr_text": "ACCRA",
                            "type": "field",
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": "01765afe-8207-4664-b34f-429f52a318bb"
                        },
                        {
                            "id": "efce870e-fe72-4536-8d3c-61401e17311a",
                            "label": "Date_of_Issue",
                            "xmin": 427,
                            "ymin": 443,
                            "xmax": 590,
                            "ymax": 466,
                            "score": 0.84667075000000002749089844655827619135379791259765625,
                            "ocr_text": "03/10/2019",
                            "type": "field",
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": "729ec0cc-e3cb-4ac9-aa52-05043802d0df"
                        },
                        {
                            "id": "a64edc91-8bc3-4b95-83f8-ec19a32bb922",
                            "label": "Date_of_expiry",
                            "xmin": 744,
                            "ymin": 434,
                            "xmax": 902,
                            "ymax": 458,
                            "score": 0.996871300000000015728573998785577714443206787109375,
                            "ocr_text": "02/10/2029",
                            "type": "field",
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": "cfb409d0-b861-422b-be02-6296df1545da"
                        },
                        {
                            "id": "6b4a250c-e794-472d-b465-6e83d353befd",
                            "label": "MRZ",
                            "xmin": 20,
                            "ymin": 508,
                            "xmax": 936,
                            "ymax": 563,
                            "score": 0.9982944000000000261962895820033736526966094970703125,
                            "ocr_text": "< INDJOSHI << ASHUTOSH <<<<<<<<<<<<<<<<<<<<<<<<",
                            "type": "field",
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": "1a426fb6-644e-4f5d-8a41-7f36538d2bd8"
                        },
                        {
                            "id": "fb05dad1-e143-474a-b1ee-95da11152983",
                            "label": "table",
                            "xmin": 42,
                            "ymin": 62,
                            "xmax": 951,
                            "ymax": 317,
                            "score": 1,
                            "ocr_text": "table",
                            "type": "table",
                            "cells": [
                                {
                                    "id": "48f34157-07e4-41b7-8f33-62f3c599561c",
                                    "row": 1,
                                    "col": 1,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 22,
                                    "ymin": 73,
                                    "xmax": 295,
                                    "ymax": 134,
                                    "score": 0.443603519999999973411064502215594984591007232666015625,
                                    "text": "",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "c594b490-0ea1-4aa2-9b8e-9b8166abe4ce",
                                    "row": 1,
                                    "col": 2,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 294,
                                    "ymin": 68,
                                    "xmax": 568,
                                    "ymax": 128,
                                    "score": 0.2391357400000000132944677488922025077044963836669921875,
                                    "text": "P",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "765a70ee-74f7-42e2-a96a-0766753ad514",
                                    "row": 1,
                                    "col": 3,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 567,
                                    "ymin": 68,
                                    "xmax": 669,
                                    "ymax": 123,
                                    "score": 0.1784668000000000087634788314971956424415111541748046875,
                                    "text": "IND",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "68dbc644-28e3-4541-8c79-127fa6bb9c08",
                                    "row": 1,
                                    "col": 4,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 668,
                                    "ymin": 62,
                                    "xmax": 927,
                                    "ymax": 122,
                                    "score": 0.299804699999999979542764094730955548584461212158203125,
                                    "text": "24813398",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "e3228fbc-bc01-48f0-bf89-455ce8cbd83e",
                                    "row": 2,
                                    "col": 1,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 23,
                                    "ymin": 126,
                                    "xmax": 296,
                                    "ymax": 179,
                                    "score": 0.443603519999999973411064502215594984591007232666015625,
                                    "text": "",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "854ad22d-cf9b-4825-8ece-c6507a7e744e",
                                    "row": 2,
                                    "col": 2,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 295,
                                    "ymin": 121,
                                    "xmax": 569,
                                    "ymax": 173,
                                    "score": 0.25,
                                    "text": "JOSHI",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "b9bdff87-331b-4aec-ad55-2f19b0a57ecb",
                                    "row": 2,
                                    "col": 3,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 568,
                                    "ymin": 120,
                                    "xmax": 670,
                                    "ymax": 168,
                                    "score": 0.1866455099999999867055322511077974922955036163330078125,
                                    "text": "",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "3509ea13-ac5f-4279-97b3-27991bd84939",
                                    "row": 2,
                                    "col": 4,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 669,
                                    "ymin": 115,
                                    "xmax": 928,
                                    "ymax": 167,
                                    "score": 0.299804699999999979542764094730955548584461212158203125,
                                    "text": "",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "51f01928-5cd4-4330-9174-3a6df18277d6",
                                    "row": 3,
                                    "col": 1,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 24,
                                    "ymin": 171,
                                    "xmax": 298,
                                    "ymax": 239,
                                    "score": 0.443603519999999973411064502215594984591007232666015625,
                                    "text": "",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "ef57226f-b9c9-4782-8b74-5d1cc7b3e1ce",
                                    "row": 3,
                                    "col": 2,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 296,
                                    "ymin": 166,
                                    "xmax": 571,
                                    "ymax": 233,
                                    "score": 0.294189450000000018992096784131717868149280548095703125,
                                    "text": "ASHUTOSH",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "1efa3d2d-1e79-4220-a3ee-55fd176c4348",
                                    "row": 3,
                                    "col": 3,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 569,
                                    "ymin": 165,
                                    "xmax": 672,
                                    "ymax": 228,
                                    "score": 0.2197265599999999874381018116764607839286327362060546875,
                                    "text": "",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "b5f314ad-ba34-4676-995c-b702049bbaf1",
                                    "row": 3,
                                    "col": 4,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 670,
                                    "ymin": 160,
                                    "xmax": 930,
                                    "ymax": 227,
                                    "score": 0.260253899999999982473042337005608715116977691650390625,
                                    "text": "",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "046b9ed6-662f-4285-b0be-132e1aed61a8",
                                    "row": 4,
                                    "col": 1,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 26,
                                    "ymin": 231,
                                    "xmax": 299,
                                    "ymax": 317,
                                    "score": 0.443603519999999973411064502215594984591007232666015625,
                                    "text": "T",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "3bd5b3d6-f143-47b3-b422-9d4ad4d2754a",
                                    "row": 4,
                                    "col": 2,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 298,
                                    "ymin": 226,
                                    "xmax": 572,
                                    "ymax": 312,
                                    "score": 0.311279299999999981007903215868282131850719451904296875,
                                    "text": "INDIAN",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "b73f91e7-aa55-4278-a14c-55311d06488b",
                                    "row": 4,
                                    "col": 3,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 571,
                                    "ymin": 225,
                                    "xmax": 673,
                                    "ymax": 306,
                                    "score": 0.2324218799999999973682207610181649215519428253173828125,
                                    "text": "M",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                },
                                {
                                    "id": "134d2890-7814-4e78-b26c-b934dde832a9",
                                    "row": 4,
                                    "col": 4,
                                    "row_span": 1,
                                    "col_span": 1,
                                    "label": "",
                                    "xmin": 672,
                                    "ymin": 220,
                                    "xmax": 931,
                                    "ymax": 305,
                                    "score": 0.275390619999999974876203623352921567857265472412109375,
                                    "text": "29/07/1989",
                                    "row_label": "",
                                    "verification_status": "correctly_predicted",
                                    "status": "",
                                    "failed_validation": "",
                                    "label_id": ""
                                }
                            ],
                            "status": "correctly_predicted",
                            "page_no": 0,
                            "label_id": ""
                        }
                    ],
                    "page": 0,
                    "request_file_id": "3e7fc7f7-eb56-4d90-a76b-ae691ad8a181",
                    "filepath": "uploadedfiles/37cd19a1-7a2a-4406-ac18-39703aec03dc/PredictionImages/1ef00f3b-99f5-4274-a102-22750f6ce27f.jpeg",
                    "id": "b38c8793-2d0f-11ee-9fcb-a6fdec9fd459",
                    "rotation": 0,
                    "file_url": "uploadedfiles/37cd19a1-7a2a-4406-ac18-39703aec03dc/RawPredictions/3e7fc7f7-eb56-4d90-a76b-ae691ad8a181.jpg",
                    "request_metadata": "",
                    "processing_type": "sync",
                    "size": {
                        "width": 961,
                        "height": 642
                    }
                }
            ],
            "signed_urls": {
                "uploadedfiles/37cd19a1-7a2a-4406-ac18-39703aec03dc/PredictionImages/1ef00f3b-99f5-4274-a102-22750f6ce27f.jpeg": {
                    "original": "https://nnts.imgix.net/uploadedfiles/37cd19a1-7a2a-4406-ac18-39703aec03dc/PredictionImages/1ef00f3b-99f5-4274-a102-22750f6ce27f.jpeg?expires=1690540012&or=0&s=d14013f420d4ec2a32b37ebd77f47fb9",
                    "original_compressed": "https://nnts.imgix.net/uploadedfiles/37cd19a1-7a2a-4406-ac18-39703aec03dc/PredictionImages/1ef00f3b-99f5-4274-a102-22750f6ce27f.jpeg?auto=compress&expires=1690540012&or=0&s=283c913ec1ccab51251dde47427c13ba",
                    "thumbnail": "https://nnts.imgix.net/uploadedfiles/37cd19a1-7a2a-4406-ac18-39703aec03dc/PredictionImages/1ef00f3b-99f5-4274-a102-22750f6ce27f.jpeg?auto=compress&expires=1690540012&w=240&s=8b0458f5fabf3a595a2837b5f7dceecc",
                    "acw_rotate_90": "https://nnts.imgix.net/uploadedfiles/37cd19a1-7a2a-4406-ac18-39703aec03dc/PredictionImages/1ef00f3b-99f5-4274-a102-22750f6ce27f.jpeg?auto=compress&expires=1690540012&or=270&s=6e196b68e03f0a73de48aa9a2a9e8cc8",
                    "acw_rotate_180": "https://nnts.imgix.net/uploadedfiles/37cd19a1-7a2a-4406-ac18-39703aec03dc/PredictionImages/1ef00f3b-99f5-4274-a102-22750f6ce27f.jpeg?auto=compress&expires=1690540012&or=180&s=a69968f36e10ce43bb6d8f5ddb98dd23",
                    "acw_rotate_270": "https://nnts.imgix.net/uploadedfiles/37cd19a1-7a2a-4406-ac18-39703aec03dc/PredictionImages/1ef00f3b-99f5-4274-a102-22750f6ce27f.jpeg?auto=compress&expires=1690540012&or=90&s=344605421e164b2bbfe3ff66fc334b02",
                    "original_with_long_expiry": "https://nnts.imgix.net/uploadedfiles/37cd19a1-7a2a-4406-ac18-39703aec03dc/PredictionImages/1ef00f3b-99f5-4274-a102-22750f6ce27f.jpeg?expires=1706077612&or=0&s=5bc2ed53b64f98b8f3fc0e6210d58dba"
                },
                "uploadedfiles/37cd19a1-7a2a-4406-ac18-39703aec03dc/RawPredictions/3e7fc7f7-eb56-4d90-a76b-ae691ad8a181.jpg": {
                    "original": "https://nanonets.s3.us-west-2.amazonaws.com/uploadedfiles/37cd19a1-7a2a-4406-ac18-39703aec03dc/RawPredictions/3e7fc7f7-eb56-4d90-a76b-ae691ad8a181.jpg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA5F4WPNNTLX3QHN4W%2F20230728%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20230728T062652Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&response-cache-control=no-cache&X-Amz-Signature=09cb96ce89f65929c778bcfed7efaa700deca11a68f6356a0840e1ea8c94a5bd",
                    "original_compressed": "",
                    "thumbnail": "",
                    "acw_rotate_90": "",
                    "acw_rotate_180": "",
                    "acw_rotate_270": "",
                    "original_with_long_expiry": ""
                }
            }
        }';

        // dd(gettype($response));
        $responseData = json_decode($response, true);
        // if ($responseData === null) {
        //     echo "JSON decoding error: " . json_last_error_msg();exit;
        // } else {
        //     echo "Valid Data";exit;
        // }

        $JSON_final = [];

        $code = null;
        $passport = null;
        $surname = null;
        $firstname = null;
        $nationality = null;
        $sex = null;
        $date_of_birth = null;
        $place_of_birth = null;
        $authority = null;
        $date_of_issue = null;
        $date_of_expire = null;
        $MRZ = null;

        foreach ($responseData['result'][0]['prediction'] as $prediction) {
            $predictionData = $prediction['label'];
            $predictionData_value = $prediction['ocr_text'];
            $predictionData_value = stripslashes($predictionData_value);

            $JSON_final[] = [
                $predictionData => $predictionData_value,
            ];

            if ($predictionData === 'Code') {
                $code = $predictionData_value;
            } else if ($predictionData === 'Passport_Number') {
                $passport = $predictionData_value;
            } else if ($predictionData === 'Surname') {
                $surname = $predictionData_value;
            } else if ($predictionData === 'First_Name') {
                $firstname = $predictionData_value;
            } else if ($predictionData === 'Nationality') {
                $nationality = $predictionData_value;
            } else if ($predictionData === 'Sex') {
                $sex = $predictionData_value;
            } else if ($predictionData === 'Date_of_Birth') {
                $date_of_birth = $predictionData_value;
            } else if ($predictionData === 'Authority') {
                $authority = $predictionData_value;
            } else if ($predictionData === 'Date_of_Issue') {
                $date_of_issue = $predictionData_value;
            } else if ($predictionData === 'Date_of_expiry') {
                $date_of_expire = $predictionData_value;
            } else if ($predictionData === 'MRZ') {
                $MRZ = $predictionData_value;
            } else if ($predictionData === 'Place_of_birth') {
                $place_of_birth = $predictionData_value;
            }

        }
        $jsonData = json_encode($JSON_final);
        Applications::create([
            'visa_id' => $id,
            'code' => $code,
            'passport_number' => $passport,
            'surname' => $surname,
            'firstname' => $firstname,
            'nationality' => $nationality,
            'sex' => $sex,
            'date_of_birth' => $date_of_birth,
            'place_of_birth' => $place_of_birth,
            'authority' => $authority,
            'date_of_issue' => $date_of_issue,
            'date_of_expire' => $date_of_expire,
            'MRZ' => $MRZ,
            'application_JSON' => $jsonData,
        ]);

        // Encode the $JSON_final array as a JSON string without white spaces
        $jsonResponse = json_encode($JSON_final, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        // Check if JSON encoding was successful
        if ($jsonResponse === false) {
            // Handle the JSON encoding error here
            return response()->json(['error' => 'Invalid JSON data']);
        }

        // Return the JSON response
        // dd($jsonResponse);
        return response()->json($jsonResponse);
    }

}

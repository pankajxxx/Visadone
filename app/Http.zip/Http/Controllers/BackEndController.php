<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BackEndController extends Controller
{
    //
    public function user_login(Request $request)
    {
        $credentials = $request->only('mobile_number', 'password');
        // dd($credentials);
        if (auth()->attempt($credentials)) {
            // Authentication Passed
            $user = auth()->user(); // Retrieve the authenticated user

            // Create session
            session([
                'id' => $user->id,
                'name' => $user->first_name ." ".$user->last_name,
                'email' => $user->email,
                'user_type' => $user->user_type,
                'country_origin' => $user->country,
                'branch_id' => $user->branch_id,
            ]);
            return redirect('/');
        } else {
            // Authentication failed
            return view("layout/login");
        }
    }

    public function logout()
    {
        Auth::logout();

        // Destroy the session
        session()->invalidate();
        session()->regenerateToken();

        return redirect('/login');
    }

}

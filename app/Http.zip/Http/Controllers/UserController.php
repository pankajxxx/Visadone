<?php

namespace App\Http\Controllers;

use App\Models\Users;
use App\Models\Branch;
use App\Models\Agency;


use DB;
use Illuminate\Http\Request;

class UserController extends Controller
{
    //
    public function __construct()
    {

        // $this->middleware(['role:Admin']);
        // $this->middleware('permission:Users add',['only' => ['create']]);
        // $this->middleware('permission:Users edit',['only' => ['edit']]);
        // $this->middleware('permission:Users delete',['only' => ['bulk_delete', 'destroy']]);
        // $this->middleware('permission:Users list');
    }

    public function index()
    {
        // $user = Auth::user();
        // if ($user->group_id == null || $user->user_type == "S") {
        $index['data'] = Users::whereUser_type("C")->orWhere('user_type', 'S')->get();
        $index['branch'] = Branch::get();
        $index['country'] = DB::table('country_info')->get();
        $index['currency'] = DB::table('currency_configuration_data')->get();
        $index['branch'] = DB::table('branches')->get();
        $index['agency'] = Agency::get();

        // }else{
        //     $index['data'] = User::where('group_id',$user->group_id)->whereUser_type("O")->get();
        //
        // }

        // dd($index);
        return view("users.index", $index);
    }

    public function create()
    {
        $data['country'] = DB::table('country_info')->get();

        // dd($data);
        return view("users.create", $data);
    }

    public function edit($id)
    {
        $data['country'] = DB::table('country_info')->get();
        $data['user'] = DB::table('users')->where('id', $id)->get();
        $data['branch'] = DB::table('branches')->get();
        $data['user_type_data'] = DB::table('user_type_data')->get();
        // dd($data);
        return view("users.view", $data);
    }

    public function store(Request $request)
    {
        // dd($request);
        try {
            $id = Users::create(['first_name' => $request->first_name . " " . $request->last_name, 'email' => $request->email, 'password' => bcrypt($request->password), 'user_type' => 'C', 'status' => 1])->id;
            $user = Users::find($id);

            // $user->login_status = 1;
            $user->first_name = $request->first_name;
            $user->last_name = $request->last_name;
            $user->mobile_number = $request->mobno;
            $user->Country_of_residences = $request->country;
            $user->country = $request->country;
            $user->api_token = bin2hex(random_bytes(60));
            $user->status = 1;
            $user->save();

            $data['country'] = DB::table('country_info')->get();
            return view("Dynamic_form.index", $data);
        } catch (\Expection $e) {
            // dd($e);
            return view("layout.500");
        }
    }

    public function update(Request $request)
    {
        // dd($request);
        try {
            DB::table('users')
                ->where('id', $request->id) // Specify the condition to select the record(s) to update
                ->update(['first_name' => $request->first_name,
                    'last_name' => $request->last_name,
                    'mobile_number' => $request->mobile_number,
                    'Country_of_residences' => $request->Country_of_residences,
                    'role' => $request->user_role,
                    'branch_id' => $request->branch,
                    'status' => $request->status]); // Set the new values for the columns

                    return redirect('/users');
        } catch (\Exception $e) {
            // dd($e);
            return view("layout.500");
        }

    }

}

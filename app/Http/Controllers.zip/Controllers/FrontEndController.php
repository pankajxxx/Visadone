<?php

namespace App\Http\Controllers;

use App\Models\DocumentRules;
use App\Models\Users;
use App\Models\VisaOffers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FrontEndController extends Controller
{
    //User Register
    public function user_register(Request $request)
    {
        try {
            $messages = [
                'email.unique' => 'User already exists.',
                'mobile_number.unique' => 'User already exists.',
            ];
            $validation = Validator::make($request->all(), [
                'mobno' => 'required',
                'password' => 'required|same:confirm_password',
                'email' => 'required|unique:users,email',
                'first_name' => 'required',
                'last_name' => 'required',
            ], $messages);

            $errors = $validation->errors();

            if (count($errors) > 0) {
                $data['success'] = "0";
                $data['message'] = implode(", ", $errors->all());
                $data['userinfo'] = "";

            } else {

                $id = Users::create(['first_name' => $request->first_name . " " . $request->last_name, 'email' => $request->email, 'password' => bcrypt($request->password), 'user_type' => 'C', 'status' => 1])->id;
                $user = Users::find($id);

                // $user->login_status = 1;
                $user->first_name = $request->first_name;
                $user->last_name = $request->last_name;
                $user->mobile_number = $request->mobno;
                $user->Country_of_residences = $request->country;
                $user->country = $request->country;
                $user->api_token = bin2hex(random_bytes(60));
                $user->status = 1;
                $user->save();
                $data['success'] = "1";
                $data['message'] = "You have Registered Successfully!";
                $data['userinfo'] = array('user_id' => "$user->id", 'api_token' => $user->api_token, 'user_name' => $user->first_name . " " . $user->last_name, 'mobno' => $user->mobile_number, 'emailid' => $user->email, 'country' => "$user->country", 'password' => $user->password, 'status' => "$user->status", 'timestamp' => date('Y-m-d H:i:s', strtotime($user->created_at)), 'Country of Residences' => $user->country);

            }

            $data1 = array('name' => "Cars In Africa");
            $message = $data['message'];
            $to = $request->emailid;
            $name = $request->first_name . $request->last_name;

            //For Sending Mail After register.
            // $obj = new MailController();
            // $obj->basic_email($to, $name, $message);

            return response()->json($data);

        } catch (\Exception $e) {
            //if Exception Happens 500 Error.
            $data['success'] = "0";
            $data['message'] = "Some Thing Went Wrong Try Again";
            $data['userinfo'] = "null";
            return response()->json($data);
        }

    }

    public function user_login(Request $request)
    {
        $credentials = $request->only('mobile_number', 'password');

        if (auth()->attempt($credentials)) {
            // Authentication Passed
            $user = auth()->user(); // Retrieve the authenticated user

            $data['success'] = true;
            $data['message'] = "You have signed in successfully!";
            $data['userinfo'] = [
                "user_id" => $user->id,
                "api_token" => $user->api_token,
                "user_name" => $user->first_name,
                "user_type" => $user->user_type,
                "mobno" => $user->mobile_number,
                "emailid" => $user->email,
                "gender" => $user->gender,
                "type" => $user->user_type,
                "status" => $user->status,
                "timestamp" => $user->created_at->format('Y-m-d H:i:s'),
            ];
        } else {
            // Authentication failed
            $data['success'] = false;
            $data['message'] = "Invalid login credentials";
            $data['userinfo'] = null;
        }

        return response()->json($data);
    }

    public function getOffer_view($nationality, $destination)
    {
        try {

            // $data['success'] = "1";
            // $data['message'] = "Offers List";
            // $data['offerinfo'] = $data['offers'];
            $data = VisaOffers::where('nationality', 'LIKE', '%' . $nationality . '%')
                ->where('destination', 'LIKE', '%' . $destination . '%')
                ->get();

        } catch (\Exception $e) {
            // dd($e);
            $data['success'] = "0";
            $data['message'] = "internal Server Error";
            $data['offerinfo'] = [];
        }

        return response()->json($data);
    }

    public function getOffer_documentrules($id)
    {
        try {

            $data = DocumentRules::where('offer_id', $id)
                ->get();

        } catch (\Exception $e) {
            // dd($e);
            $data['success'] = "0";
            $data['message'] = "internal Server Error";
            $data['offerinfo'] = [];
        }

        return response()->json($data);
    }

    public function getDocuments($id)
    {
        try {
            $data = DocumentRules::where('offer_id', $id)->get();
        } catch (\Exception $e) {
            $data = "Internal Server Error";
        }

        return response()->json($data);
    }

    public function store(Request $request)
    {

        try {

            $id = DocumentRules::create(['nationality' => $request->nationality,
                'destination' => $request->destination,
                'offer_id' => $request->offer_id,
                'document_type' => $request->document_type,
                'document_name' => $request0->document_name])->id;

            $user = DocumentRules::find($id);

            $user->document_needed = $request->document_mandatory;
            $user->document_description = $request->message;
            $user->visa_type = $request->document_requiredments;

            $user->save();

            $data['success'] = "1";
            $data['message'] = "Offer Created";
            $data['offerinfo'] = [
                'Nationality' => $request->nationality,
                'Destination' => $request->destination,
                'Visa Type' => $request->visa_type,
                'Visa Category' => $request->visa_category,
                'Visa Validity' => $request->visa_validity,
                'offer_id' => $id,
            ];

        } catch (\Expection $e) {
            // dd($e);
            // return view("layout.500");
            $data['success'] = "0";
            $data['message'] = "Offer not Created!";
            $data['offerinfo'] = [];

        }
        return $data;
    }

}

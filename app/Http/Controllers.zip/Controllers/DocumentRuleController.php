<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DocumentRules;
use DB;

class DocumentRuleController extends Controller
{
    //
    public function index()
    {
        $data['country'] = DB::table('country_info')->get();
        // dd($data);
        return view("Document_rule.index", $data);
    }

    public function create()
    {
        $data['country'] = DB::table('country_info')->get();
        $data['document'] = DB::table('document_list')->get();
        // dd($data);
        return view("Document_rule.create", $data);
    }

    public function getDocuments($id)
    {
        $data['country'] = DocumentRules::where('offer_id',$id)->get();
        // dd($data);
        return view("Document_rule.index", $data);
    }

    public function store(Request $request)
    {

        try {

            $id = DocumentRules::create(['nationality' => $request->nationality,
             'destination' => $request->destination,
              'offer_id' => $request->offer_id,
               'document_type' => $request->document_type,
               'document_name' => $request->document_name])->id;

            $user = DocumentRules::find($id);

            $user->document_needed = $request->document_mandatory;
            $user->document_description = $request->message;
            $user->visa_type = $request->document_requiredments;

            $user->save();

            $data['success'] = "1";
            $data['message'] = "Offer Created";
            $data['offerinfo'] = [
                'Nationality' => $request->nationality,
                'Destination' => $request->destination,
                'Visa Type' => $request->visa_type,
                'Visa Category' => $request->visa_category,
                'Visa Validity' => $request->visa_validity,
                'offer_id' => $id,
            ];
            $data['country'] = DB::table('country_info')->get();
           return view("Document_rule.index",$data);
        } catch (\Expection $e) {
            // dd($e);
           return view("layout.500");


        }

    }





}

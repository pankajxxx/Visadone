<?php

namespace App\Http\Controllers;

use App\Models\VisaOffers;
use DB;
use Illuminate\Http\Request;

class OfferController extends Controller
{
    //
    public function index()
    {
        $data = DB::table('country_info')->get();
        // dd($data);
        return view("offers.index", $data);
    }

    public function create()
    {
        try {
            $data['country'] = DB::table('country_info')->get();

            return view("offers.create", $data);
        } catch (\Exception $e) {
            return view("layout.500");
        }

    }

    public function getoffers($destination)
    {
        $data = VisaOffers::where('destination', $destination)->get();
        return response()->json($data)->setEncodingOptions(JSON_PRETTY_PRINT);
    }

    public function store(Request $request)
    {
        // printf($request);
        try {

            $id = VisaOffers::create(['nationality' => $request->nationality, 'destination' => $request->destination, 'visa_category' => $request->visa_category, 'visa_type' => $request->visa_type, 'status' => 'active'])->id;
            $user = VisaOffers::find($id);

            $user->entry_fees = $request->entery_type;
            $user->visa_description = $request->visa_description;
            $user->processing_time = $request->processing_time;
            $user->visa_validity = $request->visa_validity;
            $user->stay_validity = $request->stay_validity;
            $user->base_rate_adult = $request->base_rate_adult;
            $user->base_rate_child = $request->base_rate_child;
            $user->base_rate_Infant = $request->base_rate_Infant;
            $user->govt_fees_adult = $request->govt_fees_adult;
            $user->govt_fees_child = $request->govt_fees_child;
            $user->govt_fees_infant = $request->govt_fees_infant;
            $user->save();

            $data['success'] = "1";
            $data['message'] = "Offer Created";
            $data['offerinfo'] = [
                'Nationality' => $request->nationality,
                'Destination' => $request->destination,
                'Visa Type' => $request->visa_type,
                'Visa Category' => $request->visa_category,
                'Visa Validity' => $request->visa_validity,
                'offer_id' => $id,
            ];

            return $data;
        } catch (\Expection $e) {
            // dd($e);
            // return view("layout.500");
            $data['success'] = "0";
            $data['message'] = "Offer not Created!";
            $data['offerinfo'] = [];

        }

    }

    public function getOffer_view(Request $request)
    {

        try {
            $data['offers'] = VisaOffers::where('nationality', 'LIKE', '%' . $request->nationality . '%')
                ->where('destination', 'LIKE', '%' . $request->destination . '%')
                ->get();
            // if(empty($data['offers'])){
            //     dd("Empty Hai");
            // }else{
            //     dd("Not Empty");
            // }
            // return response()->json($data);
            return view("offers.index", $data);

        } catch (\Exception $e) {
            // dd($e);
            return view("layout.500");
        }

    }
}

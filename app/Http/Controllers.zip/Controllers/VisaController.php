<?php

namespace App\Http\Controllers;

use App\Models\Visa;
use DB;
use Illuminate\Http\Request;


class VisaController extends Controller
{
    //
    public function __construct()
    {

        // $this->middleware(['role:Admin']);
        // $this->middleware('permission:Users add',['only' => ['create']]);
        // $this->middleware('permission:Users edit',['only' => ['edit']]);
        // $this->middleware('permission:Users delete',['only' => ['bulk_delete', 'destroy']]);
        // $this->middleware('permission:Users list');
    }

    public function index()
    {
        // $user = Auth::user();
        // if ($user->group_id == null || $user->user_type == "S") {

            $index['data'] = DB::table('visa_data')
            ->join('users', 'visa_data.user_id', '=', 'users.id')
            ->select('users.*', 'visa_data.*')
            ->where('visa_data.visa_status', '=', 'active')
            ->get();
            $index['country'] = DB::table('country_info')->get();

        // }else{
        //     $index['data'] = User::where('group_id',$user->group_id)->whereUser_type("O")->get();
        //
        // }

        // dd($index);
        return view("visa.index", $index);
    }


    public function create(){
        $index['country'] = DB::table('country_info')->get();
        return view("visa.create",$index);
    }

    public function store(Request $request){
        // printf($request);
        try{



                $id = Visa::create(['user_id' => $request->user_id, 'destination' => $request->destination, 'visa_offer' => $request->visa_offer, 'offer_id' => $request->offer_id, 'visa_status' => 'active'])->id;
                $user = Visa::find($id);

                $user->branch_id = $request->branch_id;
                $user->travel_date_from =  $request->travel_date_from ?? date('Y-m-d');
                $user->travel_date_to =  $request->travel_date_to ?? date('Y-m-d');
                $user->visa_type_selected = $request->visa_type;
                $user->visa_fees = $request->visa_fees;
                $user->visa_status = $request->visa_status;
                $user->save();

            $data['success'] = "1";
                $data['message'] = "Your Application Submitted Successfully!";
                $data['userinfo'] = [
                    'user_id' => $request->user_id,
                    'Destination' => $request->destination,
                    'Visa Type' => $request->visa_type,
                    'Visa Offer' => $request->visa_offer,
                    'travel_from' => $request->travel_date_from,
                    'application_id'=> $id
                ];


            return $data;
        }catch(\Expection $e){
            // dd($e);
            return view("layout.500");
        }

    }


}

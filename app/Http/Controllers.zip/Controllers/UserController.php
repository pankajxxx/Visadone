<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Users;

class UserController extends Controller
{
    //
    public function __construct()
    {

        // $this->middleware(['role:Admin']);
        // $this->middleware('permission:Users add',['only' => ['create']]);
        // $this->middleware('permission:Users edit',['only' => ['edit']]);
        // $this->middleware('permission:Users delete',['only' => ['bulk_delete', 'destroy']]);
        // $this->middleware('permission:Users list');
    }

    public function index()
    {
        // $user = Auth::user();
        // if ($user->group_id == null || $user->user_type == "S") {
            $index['data'] = Users::whereUser_type("C")->orWhere('user_type', 'S')->get();

        // }else{
        //     $index['data'] = User::where('group_id',$user->group_id)->whereUser_type("O")->get();
        //
        // }

        // dd($index);
        return view("users.index", $index);
    }


}

<!-- resources/views/loading.blade.php -->
<div id="loading-screen">
    <!-- Your loading screen content, e.g., spinner or animation -->
    <img src="loader.svg" alt="loading...">
</div>

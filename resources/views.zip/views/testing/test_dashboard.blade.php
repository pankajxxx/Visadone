@extends('layout.app')



@section('footer')
    @include('layout.footer')
@endsection
